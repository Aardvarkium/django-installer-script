================================
 Personalizar Virtualenvwrapper
================================

virtualenvwrapper agrega varios ganchos que puedes usar para cambiar tus
configuraciones, el entorno del shell, u otras configuraciones al crear,
eliminar o cambiar entre entornos. Estos ganchos son expuestos en dos formas:

.. toctree::
   :maxdepth: 1

   scripts
   plugins
